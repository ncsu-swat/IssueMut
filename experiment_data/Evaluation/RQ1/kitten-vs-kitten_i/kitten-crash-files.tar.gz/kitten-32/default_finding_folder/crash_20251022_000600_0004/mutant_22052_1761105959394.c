#include <x86gprintrin.h>
typedef unsigned int uword_t __attribute__ ( ( mode ( __word__ ) ) ) ;
void __attribute__ ( ( target ( "general-regs-only" ) , interrupt ) )
UINTR_handler ( struct __uintr_frame
UINTR_handler ( struct __uintr_frame * p , uword_t uirrv ) , uword_t uirrv ) { }
