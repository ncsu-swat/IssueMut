float
fs
=
__builtin_nansf
(
"=@ccnbe"
"=g"
"Video GOP Closure"
"xxxxxxxxxxxxxxxxxxxxxxxxx"
"RDS Traffic Program"
U"ab"
"local-dynamic"
"r10"
"pickANumber2 "
)
;
