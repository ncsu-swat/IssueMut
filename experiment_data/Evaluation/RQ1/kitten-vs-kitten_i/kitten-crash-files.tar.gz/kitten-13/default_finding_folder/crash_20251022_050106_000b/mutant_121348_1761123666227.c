__INT32_TYPE__ * m1 ( __INT32_TYPE__ i ) __attribute__ ( ( alloc_align ( 1 ) ) ) ;
__INT32_TYPE__ test1 ( __INT32_TYPE__ a ) { return * m1 ( a ) ; }
__INT32_TYPE__ test2 ( __SIZE_TYPE__ a ) { return * m1 ( a ) ; }
__INT32_TYPE__ * m2 ( __SIZE_TYPE__ i ) __attribute__ ( ( alloc_align ( 1 ) ) ) ;
__INT32_TYPE__ test3 ( __INT32_TYPE__ a ) { return * m2 ( a ) ; }
__INT32_TYPE__ test4 ( __SIZE_TYPE__ a ) { return * m2 ( a ) ; }
struct Empty { }
struct MultiArgs {
__INT64_TYPE__ a , b ;
;
__INT32_TYPE__ * m3 ( struct Empty s , __int128_t i )
__attribute__ ( ( alloc_align ( 2 ) ) ) ;
__INT32_TYPE__ test5 ( __int128_t a ) {
struct Empty e ;
* m3 ( e , a ) ;
}
__INT32_TYPE__ * m4 ( struct MultiArgs s , __int128_t i )
__attribute__ ( ( alloc_align ( 2 ) ) ) ;
__INT32_TYPE__ test6 ( __int128_t a ) {
struct MultiArgs e ;
return * m4 ( e , a ) ;
}
