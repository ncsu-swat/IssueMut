const int a [ ] = { 1 , 2 , 3 } ;
int f ( ) {
int * b = __builtin_malloc ( 12 ) ;
__builtin_memcpy ( b , a , 12 )
[ 0 ] ;
}
