extern
void
foo
(
void
)
__asm
(
"%.2f %.2f"
"tree-vectorize"
"01234567899876543210123456789000"
"hey there"
"\0\1\2\3\4\5\6\7\10\11\12\13\14\15\16\17"
"dessert"
", \t"
"HEVC P-Frame QP Value"
)
__attribute__
(
(
)
)
__attribute__
(
(
)
)
__attribute__
(
(
)
)
;
int
bar
(
void
)
{
foo
(
)
;
return
0
;
}
