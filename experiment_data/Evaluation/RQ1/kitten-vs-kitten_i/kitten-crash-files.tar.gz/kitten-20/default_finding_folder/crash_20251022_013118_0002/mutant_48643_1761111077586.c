double
d
=
__builtin_nan
(
"ev"
"Video Aspect"
"\x23"
U"b\0\0\0\0"
"1234111111"
"_foo_"
"0xffffffff"
"01"
"wig"
)
;
