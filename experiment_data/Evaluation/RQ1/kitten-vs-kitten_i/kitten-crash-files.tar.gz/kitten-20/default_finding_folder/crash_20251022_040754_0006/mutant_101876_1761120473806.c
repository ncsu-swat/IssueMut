void f ( void * p ) { p [ 1 ] ; }
