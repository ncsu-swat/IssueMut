float
f
[
]
=
{
__builtin_nan
(
""
)
,
__builtin_nans
(
""
)
,
}
;
double
d
[
]
=
{
__builtin_nan
(
""
)
,
__builtin_nans
(
"37037337637938238538839139439740040340640941241541842142442743043343643944"
"  xor %eax, %eax\n"
"<<<<<<< "
"Initial Delay for VBV Control"
"4"
"910"
L"\x4142\x4344"
"movl $0,%%ebx"
)
,
}
;
