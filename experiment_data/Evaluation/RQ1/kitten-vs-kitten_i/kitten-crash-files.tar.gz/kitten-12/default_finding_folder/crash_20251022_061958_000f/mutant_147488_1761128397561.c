void foo ( char * p ) {
__SIZE_TYPE__ s = ~ ( __SIZE_TYPE__ ) 0 ;
* p = 0 ;
__builtin_memset ( p + 0 , 0 , s ) ;
}
