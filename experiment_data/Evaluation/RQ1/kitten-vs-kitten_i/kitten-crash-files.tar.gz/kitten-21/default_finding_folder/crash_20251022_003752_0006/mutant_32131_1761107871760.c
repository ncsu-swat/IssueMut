double
d
=
__builtin_nan
(
"mov r6,%0"
"S"
"wf2"
L"a3"
"Foo()"
"Vertical MV Search Range"
"%02X"
)
;
