double
d
=
__builtin_nan
(
""
)
;
float
f
=
__builtin_nan
(
"=&rm"
"x %c\n"
u"ff"
"test2"
"MPEG4 Maximum QP Value"
"arch=alderlake"
"thunk-extern"
"__WINT_MAX__"
"3:5"
)
;
