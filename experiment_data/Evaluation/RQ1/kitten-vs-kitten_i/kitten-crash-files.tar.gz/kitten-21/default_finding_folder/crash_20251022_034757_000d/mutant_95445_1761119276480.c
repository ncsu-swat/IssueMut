float
f
=
__builtin_nanf
(
u"\
\
\
"
"Test1 passed\n"
)
;
