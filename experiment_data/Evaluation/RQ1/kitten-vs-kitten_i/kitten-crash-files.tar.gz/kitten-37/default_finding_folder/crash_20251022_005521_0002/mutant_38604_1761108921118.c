struct __jmp_buf_tag {
char buf [ 1 ]
typedef struct __jmp_buf_tag jmp_buf [ 1 ] ;
typedef struct __jmp_buf_tag sigjmp_buf [ 1 ] ;
extern int setjmp ( jmp_buf env ) ;
extern int sigsetjmp ( sigjmp_buf env , int savesigs ) ;
extern void longjmp ( jmp_buf env , int val ) ;
extern void siglongjmp ( sigjmp_buf env , int val ) ;
#include <stddef.h>
#include <stdlib.h>
extern int foo ( int ) __attribute__ ( ( __pure__ ) ) ;
static sigjmp_buf env ;
static void inner ( void ) {
void * ptr = malloc ( 1024 ) ;
siglongjmp ( env , 1 ) ;
free ( ptr ) ;
}
void outer ( void ) {
int i ;
foo ( 0 ) ;
i = sigsetjmp (
env ,
0 ) ;
if ( i == 0 ) {
foo ( 1 ) ;
inner ( ) ;
}
foo ( 3 ) ;
}
