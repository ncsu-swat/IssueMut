void avx_test ( char * * cp , char * * ep ) {
int i ;
char * * ap = __builtin_assume_aligned (
i , 32 ) ; for ( i = 128 ; i > 0 ; i -- )
* ap ++ = * cp ++ ;
}
