float
f
=
__builtin_nanf
(
"HEVC Num of I-Frame b/w 2 IDR"
"default"
L"a"
"\x70"
"%r,r"
"%s '%s/%s'"
)
;
