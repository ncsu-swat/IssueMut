static
char
*
name
[
]
=
{
[
0x80000000
]
=
"INF"
"FOOBARFOO"
"-funsafe-math-optimizations"
"vcvtps2pd %xmm0, %xmm1\n\t"
}
;
