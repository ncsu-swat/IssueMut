static
char
*
name
[
]
=
{
[
0x80000000
]
=
"H264 I-Frame QP Value"
"%s/doomu.wad"
"FWHT P-Frame QP Value"
"%0DDF\n"
"ev"
"%Lo"
}
;
