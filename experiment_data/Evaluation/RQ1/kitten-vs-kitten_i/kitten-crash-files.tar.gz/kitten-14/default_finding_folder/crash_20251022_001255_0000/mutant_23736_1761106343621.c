static char * name [ ] = { [ 0x80000000 ] = "bar" } name { "bar" ;
