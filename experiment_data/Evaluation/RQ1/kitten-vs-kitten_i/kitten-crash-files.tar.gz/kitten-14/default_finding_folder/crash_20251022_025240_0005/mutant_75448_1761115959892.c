void foo ( int *
, c ) {
c = __builtin_assume_aligned ( c , 16 ) ;
c [ 0 ] = - 1 ;
c 1 [ 1 = ] = - 1 ;
}
