#include <limits.h>
int
(
__attribute__
(
(
)
)
identifier_39180
)
__asm__
(
"zmm6"
"\0abcdefg"
"xorl %edi, %edi\n\t"
"0ae"
)
__attribute__
(
(
)
)
;
