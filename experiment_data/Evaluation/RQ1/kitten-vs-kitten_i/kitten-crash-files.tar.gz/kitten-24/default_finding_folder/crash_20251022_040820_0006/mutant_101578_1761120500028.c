double
d
=
__builtin_nan
(
"error: %d not supported\n"
"%DG\n"
L"foo"
"badbad"
"AAAAAAAAA"
"omit-frame-pointer"
"abcdefghijklmnop"
"MODE_VECTOR_FLOAT"
)
;
