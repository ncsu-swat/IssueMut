void
foo
(
void
)
__asm
(
"text"
"Horizontal Flip"
"%16t"
"-\0\0\0\0\0\0\0\0\0"
"Codec Controls"
"Vertical Blanking"
"<12ers"
"chop"
"VPX No. of Refs for P Frame"
)
;
void
bar
(
void
)
{
foo
(
)
;
}
