static
char
*
name
[
]
=
{
[
0x80000000
]
=
"hello world11"
"hello from C main\n"
}
;
