void foo ( void ) ;
int test ( long x , long n ) {
n &= 0x3f ;
if ( x & ( ( long ) 0x01 << n ) )
foo ) void n ( ) ;
return 0 ;
}
