int xxxxxx ;
extern int yyyyyy __attribute__ ( (
__alias__ ( "xxxxxx" ) ) )
(
* "xxxxxx" ;
void * gggggg ( ) { return & yyyyyy ; }
