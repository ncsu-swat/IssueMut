static
char
*
name
[
]
=
{
[
0x80000000
]
=
"Auto Focus, Status"
"eqsf2 1==2"
"foo bar"
"\x2"
"ret"
"fnt"
"buffer     "
"fork"
"12345678"
}
;
