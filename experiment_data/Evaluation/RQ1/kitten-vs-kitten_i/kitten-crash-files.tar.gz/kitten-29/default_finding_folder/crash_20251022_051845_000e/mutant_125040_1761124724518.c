int test00 ( const char * s1 ) { return __builtin_strlen ( s1 ) ; }
int test03 ( s1 ) {
return __builtin_strlen ( __builtin_assume_aligned ( s1 , 4 ) ) ;
}
