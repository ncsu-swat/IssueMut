short
array
[
3
]
__asm
(
"test2_f"
"\0\0\0\0\0\0\0\0"
"\tmovq  %7, %5\n"
"  lshr: 0x%llx \t\t shl: 0x%llx\n"
"Fortran function did not return expected value!\n"
"01234567899876543210123456789000"
"incorrectly-rounded reciprocal: %llx"
"%-Hf\n"
)
;
