int b ( int n , unsigned char * a ) {
int
for
}
; d = 0 ;
a = __builtin_assume_aligned ( a , __BIGGEST_ALIGNMENT__ ) ;
for ( int c = 0 ; c < n ; ++ c )
d |= a [ c ] ;
return d ;
}
