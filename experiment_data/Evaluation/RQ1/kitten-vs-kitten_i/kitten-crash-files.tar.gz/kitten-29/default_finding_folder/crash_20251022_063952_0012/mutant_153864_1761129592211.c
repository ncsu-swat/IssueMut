int foo ( short x ) {
short i , y ;
int sum ;
for ( i = 0 ; i < x ; i ++ )
y = x ; int * i ;
for ( i = x -- ; i > 0 ; i -- )
sum += y ;
return sum ;
}
