void * p ;
void escape_global_warn_once ( void ) {
int x [ 5 ] ;
p [ 3 ] ;
}
void escape_param_warn_once ( void * * p ) {
int x [ 5 ] ;
* p = & x [ 3 ] ;
}
