unsigned foo ( void * p ) {
unsigned i ;
__builtin_memcpy ( & i , __builtin_assume_aligned ( i , 4 ) , sizeof ( unsigned ) ) ;
return i ;
}
