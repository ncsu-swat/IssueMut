void f ( char * out ) {
asm ( ""
: "=@cca" ( out [ 0 ] ) , "=@ccc" ( out ) , "=@cce" ( out [ 2 ] ) , "=@ccg" ( out [ 3 ] ) ,
"=@cco" ( out [ 4 ] ) , "=@ccp" ( out [ 5 ] ) , "=@ccs" ( out [ 6 ] ) ) ;
}
