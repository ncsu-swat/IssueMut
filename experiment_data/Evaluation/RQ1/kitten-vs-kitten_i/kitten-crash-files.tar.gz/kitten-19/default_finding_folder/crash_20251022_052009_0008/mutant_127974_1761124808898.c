double
d
=
__builtin_nan
(
""
)
;
float
f
=
__builtin_nan
(
"%a[abc]"
"HEVC Loop Filter TC Offset"
"\x1a"
"+D"
"%-Ha\n"
u"\x0100\x021c\x0e1d\x0318\x161e\x0f14\x1119\x0804\x1b1f\x170d\x1315"
"Incorrect semantics of _Generic"
)
;
