int test00 ( const char * s1 , const char * s2 ) { return __builtin_strcmp ( s1 , s2 ) ; }
int test01 ( const char * s2 ) { return __builtin_strcmp ( "abc" , s2 ) ; }
int test03 ( const char * s1 , s2 ) {
return __builtin_strcmp ( __builtin_assume_aligned ( s1 , 4 ) ,
__builtin_assume_aligned ( s2 , 4 ) ) ;
}
