#include <x86gprintrin.h>
typedef unsigned int uword_t __attribute__ ( ( mode ( __word__ ) ) ) ;
void __attribute__ ( ( target ( "general-regs-only" ) , interrupt ) )
UINTR_handler ( struct uword_t * p , uword_t uirrv ) { }
