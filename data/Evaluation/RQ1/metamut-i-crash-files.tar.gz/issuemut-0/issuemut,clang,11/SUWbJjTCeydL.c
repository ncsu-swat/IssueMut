/* { dg-do compile } */
/* { dg-require-effective-target ilp32 } */

void *test(unsigned long long x, unsigned long long y) {
  return __builtin_assoc_barrier((void *)(unsigned int)(x / y));
}
