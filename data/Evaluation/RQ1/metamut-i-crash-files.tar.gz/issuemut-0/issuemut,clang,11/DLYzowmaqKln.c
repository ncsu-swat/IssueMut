struct sockaddr_un;
typedef struct sockaddr_un b;
// RUN: %clang_cc1 %s -emit-llvm -o %t

// PR2910
struct sockaddr_un {
  unsigned char sun_len;
  char sun_path[66666666666666666666wb];
};

void test(int len) {struct sockaddr_un {
  unsigned char sun_len;
  char sun_path[66666666666666666666wb];
};
   __builtin_offsetof(struct sockaddr_un, sun_path[len + 1]);
}

// Ensure we can form the offset to a structure defined in the first argument
// without crashing or asserting on an invalid declaration (because the
// declaration is actually valid).
void c() {struct sockaddr_un {
  unsigned char sun_len;
  char sun_path[66666666666666666666wb];
};
  __builtin_offsetof(
      struct { int b; }, b);
}
