/* { dg-do compile } */
/* { dg-options "-fopenmp -fdump-tree-ompexp" } */

extern void bar;

void foo(int n) {
  int i;

#pragma omp for schedule(nonmonotonic : dynamic, 2)
  for (i = 0; i < n; ++i)
    bar;
}

/* { dg-final { scan-tree-dump-times "GOMP_loop_nonmonotonic_dynamic_start" 1
 * "ompexp" } } */
/* { dg-final { scan-tree-dump-times "GOMP_loop_nonmonotonic_dynamic_next" 1
 * "ompexp" } } */
