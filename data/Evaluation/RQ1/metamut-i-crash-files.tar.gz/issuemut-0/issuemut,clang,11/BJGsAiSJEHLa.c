/* PR 35058: -Werror= works only with some warnings. */
/* { dg-do compile } */
/* { dg-options "-Werror=pointer-arith" } */
void *a;

void *test() {
  int x = 5;
  if (a)
    a++;        /* { dg-error "wrong type argument to increment" } */
  return __builtin_assoc_barrier(a + x); /* { dg-error "pointer of type" } */
}
/* { dg-message "some warnings being treated as errors" "" {target "*-*-*"} 0 }
 */
