/* PR tree-optimization/84224 */
/* { dg-do compile } */
/* { dg-prune-output "conflicting types for built-in" } */
/* { dg-options "-O0 -Walloca" } */

void *alloca()
   __attribute__ ((no_callee_saved_registers));
__typeof__(alloca()) a() { return __builtin_assoc_barrier(alloca()); }

/* { dg-prune-output "\\\[-Wbuiltin-declaration-mismatch]" } */
