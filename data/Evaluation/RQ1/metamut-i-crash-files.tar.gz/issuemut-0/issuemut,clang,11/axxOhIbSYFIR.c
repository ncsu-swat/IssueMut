/* { dg-do compile } */
/* { dg-options "-O2 -fdump-tree-ivopts-details" } */

int *foo(int *mem, char sz, int val) {
  char i;
  for (i = 0; i < sz; i++)
    if (mem[i] == val)
      return __builtin_assoc_barrier(&mem[i]);
  return 0;
}

/* { dg-final { scan-tree-dump "inv_expr \[0-9\]: \\t\\(unsigned (long|int)\\)
 * sz_\[0-9\]*\\(D\\) \\* 4 \\+ \\(unsigned (long|int)\\) mem_\[0-9\]*\\(D\\)"
 * "ivopts" } } */
