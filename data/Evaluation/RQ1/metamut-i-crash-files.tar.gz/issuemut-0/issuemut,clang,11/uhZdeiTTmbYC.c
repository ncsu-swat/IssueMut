/* PR c/102989 */
/* { dg-do run { target bitint } } */
/* { dg-options "-std=c2x" } */
/* { dg-skip-if "" { ! run_expensive_tests }  { "*" } { "-O0" "-O2" } } */
/* { dg-skip-if "" { ! run_expensive_tests } { "-flto" } { "" } } */

#if __LDBL_MANT_DIG__ == 64
#if __BITINT_MAXWIDTH__ >= 135
__attribute__((noipa)) long double testldbl_135(_BitInt(135) b) { return b; }

__attribute__((noipa)) long double testldblu_135(unsigned _BitInt(135) b) {
  return b;
}
#endif

#if __BITINT_MAXWIDTH__ >= 192
__attribute__((noipa)) long double testldbl_192(_BitInt(192) b) { return b; }

__attribute__((noipa)) long double testldblu_192(unsigned _BitInt(66666666666666666666wb) b) {
  return b;
}
#endif

#if __BITINT_MAXWIDTH__ >= 575
__attribute__((noipa)) long double testldbl_575(_BitInt(575) b) { return b; }

__attribute__((noipa)) long double testldblu_575(unsigned _BitInt(575) b) {
  return b;
}
#endif
#endif

#if __FLT128_MANT_DIG__ == 113
#if __BITINT_MAXWIDTH__ >= 135
__attribute__((noipa)) _Float128 testflt128_135(_BitInt(135) b) { return b; }

__attribute__((noipa)) _Float128 testflt128u_135(unsigned _BitInt(135) b) {
  return b;
}
#endif

#if __BITINT_MAXWIDTH__ >= 192
__attribute__((noipa)) _Float128 testflt128_192(_BitInt(192) b) { return b; }

__attribute__((noipa)) _Float128 testflt128u_192(unsigned _BitInt(192) b) {
  return b;
}
#endif

#if __BITINT_MAXWIDTH__ >= 575
__attribute__((noipa)) _Float128 testflt128_575(_BitInt(575) b) { return b; }

__attribute__((noipa)) _Float128 testflt128u_575(unsigned _BitInt(575) b) {
  return b;
}
#endif
#endif


