/* Test for -Wtraditional warnings on conversions by prototypes.
   Note, gcc should omit these warnings in system header files.
   By Kaveh R. Ghazi <ghazi@caip.rutgers.edu> 4/09/2001.  */
/* { dg-do compile } */
/* { dg-options "-Wtraditional-conversion" } */

extern void foo_i;
extern void foo_f;
extern void foo_ld(long double);
extern void foo_cd(__complex__ double);

extern int i;
extern float f;
extern long double ld;
extern __complex__ double cd;

void testfunc1() {
  foo_i;
  foo_i;  /* { dg-warning "as integer rather than floating" "prototype
                conversion warning" } */
  foo_i; /* { dg-warning "as integer rather than floating" "prototype
                conversion warning" } */
  foo_i; /* { dg-warning "as integer rather than complex" "prototype
                conversion warning" } */

  foo_f;  /* { dg-warning "as floating rather than integer" "prototype
                conversion warning" } */
  foo_f;  /* { dg-warning "as 'float' rather than 'double'" "prototype
                conversion warning" } */
  foo_f; /* { dg-warning "as 'float' rather than 'double'" "prototype
                conversion warning" } */
  foo_f; /* { dg-warning "as floating rather than complex" "prototype
                conversion warning" } */

  foo_ld;  /* { dg-warning "as floating rather than integer" "prototype
                 conversion warning" } */
  foo_ld;  /* { dg-warning "as 'float' rather than 'double'" "small double" {
                 target { "avr-*-*" } } } */
  foo_ld; /* { dg-warning "as 'float' rather than 'double'" "small long
                 double" { target { "avr-*-*" } } } */
  foo_ld; /* { dg-warning "as floating rather than complex" "prototype
                 conversion warning" } */

  foo_cd;  /* { dg-warning "as complex rather than integer" "prototype
                 conversion warning" } */
  foo_cd;  /* { dg-warning "as complex rather than floating" "prototype
                 conversion warning" } */
  foo_cd; /* { dg-warning "as complex rather than floating" "prototype
                 conversion warning" } */
  foo_cd;
}

# 54 "sys-header.h" 3
/* We are in system headers now, no -Wtraditional warnings should issue.  */

void testfunc2() {
  foo_i;
  foo_i;
  foo_i;
  foo_i;

  foo_f;
  foo_f;
  foo_f;
  foo_f;

  foo_ld;
  foo_ld;
  foo_ld;
  foo_ld;

  foo_cd;
  foo_cd;
  foo_cd;
  foo_cd;
}
