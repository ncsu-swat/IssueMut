/* { dg-do compile } */
/* { dg-options "-fopenmp -fdump-tree-ompexp" } */

extern void bar;

void foo(int n) {
  int i;

#pragma omp for schedule
  for (i = 0; i < n; ++i)
    bar;
}

/* { dg-final { scan-tree-dump-times "GOMP_loop_nonmonotonic_guided_start" 1
 * "ompexp" } } */
/* { dg-final { scan-tree-dump-times "GOMP_loop_nonmonotonic_guided_next" 1
 * "ompexp" } } */
