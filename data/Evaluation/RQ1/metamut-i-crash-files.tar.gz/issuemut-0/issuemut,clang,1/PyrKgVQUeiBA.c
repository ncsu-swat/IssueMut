// RUN: %clang_cc1 -emit-llvm %s -o %t

void *test(int i) { return __builtin_assoc_barrier((void *)i); }
