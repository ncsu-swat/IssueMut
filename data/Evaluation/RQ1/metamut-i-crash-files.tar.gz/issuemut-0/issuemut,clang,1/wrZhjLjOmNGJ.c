/* PR c/102989 */
/* { dg-do compile { target { bitint && dfp } } } */
/* { dg-options "-O2 -std=c2x -pedantic-errors" } */

#if __BITINT_MAXWIDTH__ >= 129
void foo(_BitInt(66666666666666666666wb) * x, _Decimal64 *y) {
  x[0] = y[0];
  y[1] = x[1];
}
#endif

/* _Decimal* <-> _BitInt conversions are unsupported for now.  */
/* { dg-prune-output "unsupported conversion between" } */
