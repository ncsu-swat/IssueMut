typedef unsigned short W;
typedef const W *P;

extern void g;

void f() {
  const P s = (const W[]){'R'};
  g;
}
