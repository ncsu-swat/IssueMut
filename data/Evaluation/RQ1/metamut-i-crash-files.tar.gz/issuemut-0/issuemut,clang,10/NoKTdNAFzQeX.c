struct {
} foo = {};
void *bar(void) { return __builtin_assoc_barrier(&foo); }
