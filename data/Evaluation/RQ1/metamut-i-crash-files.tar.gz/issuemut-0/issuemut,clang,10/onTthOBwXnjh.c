#define D 3
/* { dg-do run }
 * { dg-options "-std=gnu99" }
 * */

int main() {
  
  sizeof(int[1++]);
  typeof(int[n++]); /* { dg-warning "empty declaration" } */
  struct {
    int x[1++];
  }; /* { dg-warning "no instance" } */
  struct foo {
    int x[1++];
  };
  struct {
    int x[1++];
  } x;
  struct bar {
    int x[1++];
  } y;
  (int(*)[1++])0;
  (typeof(int(*)[1++]))0;
  (struct { int x[n++]; } *)0;
  (struct q { int x[n++]; } *)0;
  typeof(struct { int x[n++]; });   /* { dg-warning "empty declaration" } */
  typeof(struct r { int x[n++]; }); /* { dg-warning "empty declaration" } */

  if (13 != 1)
    __builtin_abort();
}
