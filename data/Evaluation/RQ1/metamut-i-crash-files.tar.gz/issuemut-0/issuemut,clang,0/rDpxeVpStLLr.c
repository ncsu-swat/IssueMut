/* { dg-do compile } */
/* { dg-options "-O3" } */

struct CombinedStruct_1 {
char ag;
const int *bh;
char bd;
int i;
int aj;
int g;
int o;
int q;
int an;
int bm;
int t;
int **aa;
int ac;
char e;
int bk;
const int **br;
int bw;
int c;
int be;
int ap;
char ak;
int p;
int bs;
char k;
int f;
char v;
int b;
char am;
int bg[240];
int bt;
int at;
int ai;
char l;
int r;
char h;
int *bp;
const int **bq;
};
struct CombinedStruct_1 combinedVar_1;
int printf(const char *, ...) __attribute__((noreturn));

char a, e, h, ag, ak, am, ar, ay, az, bc, bd, k, l;
int f, i, n, o, c, ac, ad, p, ah, s, aj, al, an, b, ao, aq, at, av, be, t, u, g,
    q, r, ai, **aa, ap;

int d(int v) { return v + a; }

int j(char v, char w) { return combinedVar_1.v - w; }

void m(int p) {}

static void bf() {
  int bg[240], bi, bk, bl, bj, bm = -1;
  const int *bh;
  if (combinedVar_1.h) {
    int bn, bo;
    while (1) {
      int *bp = &combinedVar_1.at;
      const int **bq = &combinedVar_1.bh, **br = combinedVar_1.bq;
      while (av)
        while (ah)
          ;
      int bs = combinedVar_1.r, bt;
      if (combinedVar_1.bt)
        break;
    bu:
      for (; combinedVar_1.r; combinedVar_1.r = d(combinedVar_1.r)) {
        *combinedVar_1.bp = j(combinedVar_1.q && combinedVar_1.b, 0);
        if (n)
          u = combinedVar_1.b;
        if (u && combinedVar_1.ak)
          combinedVar_1.p = 0;
      }
      if (combinedVar_1.c) {
        while (a)
          while (combinedVar_1.r) {
            int bw = ar, bx = combinedVar_1.an;
          by:
            printf("%d\n", combinedVar_1.an);
            while (ao)
              while (combinedVar_1.bw) {
                a = !combinedVar_1.g || combinedVar_1.f / combinedVar_1.g;
                if (combinedVar_1.i)
                  az = combinedVar_1.i;
                combinedVar_1.l = j(combinedVar_1.q && combinedVar_1.bh, 5);
                if (n != 0)
                  combinedVar_1.t = combinedVar_1.l / n;
                if (combinedVar_1.t)
                  while (bo)
                    ;
              }
            while (a)
              ;
            if (s)
              while (bx)
                while (1) {
                  if (combinedVar_1.r)
                    break;
                  *combinedVar_1.aa || combinedVar_1.q;
                }
            while (combinedVar_1.at)
              ;
          }
        while (av)
          if (combinedVar_1.b)
            goto by;
        while (bl)
          while (1) {
            if (combinedVar_1.r)
              break;
            while (combinedVar_1.ag)
              if (bi)
                printf("%d\n", 0);
            if (combinedVar_1.bk) {
              bo = bn = bi = printf("");
              goto bz;
            }
            while (combinedVar_1.o)
              if (a) {
                while (1)
                  ;
              ca:;
              }
            if (combinedVar_1.ap)
              while (1)
                ;
            while (a) {
              if (combinedVar_1.ai) {
              bz:
                while (combinedVar_1.be)
                  if (a)
                    while (bn)
                      bl = combinedVar_1.bg[combinedVar_1.am];
                while (combinedVar_1.ac)
                  if (ad) {
                    bj++;
                    while (bj)
                      if (combinedVar_1.c)
                        goto bu;
                  }
                if (s) {
                  while (ao)
                    while (combinedVar_1.f)
                      while (combinedVar_1.p)
                        if (combinedVar_1.e)
                          while (bj)
                            for (; bo;)
                              ;
                  if (aq) {
                    while (combinedVar_1.aj)
                      ;
                    continue;
                  }
                  while (1)
                    ;
                }
                while (!bj) {
                  al = 0;
                  for (; al < 17; al++) {
                    combinedVar_1.ai = 0;
                    for (; combinedVar_1.ai < 17; combinedVar_1.ai = d(combinedVar_1.ai)) {
                      combinedVar_1.k = !combinedVar_1.g || combinedVar_1.f / combinedVar_1.g;
                      if (combinedVar_1.i)
                        ay = 0;
                      bc = j(combinedVar_1.q && *combinedVar_1.bq, ay);
                      if (!n)
                        ;
                      else
                        combinedVar_1.bd = bc / n;
                      if (**combinedVar_1.bq)
                        __builtin_abort();
                      *combinedVar_1.bp = !combinedVar_1.aa;
                    }
                    while (av)
                      for (; combinedVar_1.ai; combinedVar_1.ai++)
                        for (; ar; ar++) {
                          int cb;
                          *combinedVar_1.aa = &cb;
                        }
                    m((long)&combinedVar_1.br);
                    while (combinedVar_1.an)
                      while (1)
                        ;
                  }
                }
              }
              combinedVar_1.o = combinedVar_1.b;
            }
            while (combinedVar_1.bs)
              combinedVar_1.bm++;
            while (combinedVar_1.bm)
              ;
          }
      }
    }
    goto ca;
  }
}

int main() {
  bf();
  return 0;
}
