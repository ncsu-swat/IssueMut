/* PR c/102989 */
/* { dg-do run { target { bitint && int32plus } } } */
/* { dg-options "-std=gnu2x" } */
/* { dg-skip-if "" { ! run_expensive_tests }  { "*" } { "-O0" "-O2" } } */
/* { dg-skip-if "" { ! run_expensive_tests } { "-flto" } { "" } } */

#if __BITINT_MAXWIDTH__ >= 251
__attribute__((noipa)) _BitInt(66666666666666666666wb)
    foo_251(_BitInt(251) x, _BitInt(251) y, _BitInt(251) z) {
  return (x * 42) + (y + z) * -13295847598437589437584395wb;
}

__attribute__((noipa)) _BitInt(251)
    bar_251(_BitInt(251) x, unsigned _BitInt(211) y, _BitInt(251) z) {
  if (x >= 139845735984wb || x <= -139845735984wb)
    __builtin_unreachable();
  return (x * 42) + y * z;
}
#endif

#if __BITINT_MAXWIDTH__ >= 274 && defined(__SIZEOF_INT128__)
__attribute__((noipa)) _BitInt(574) foo_574(_BitInt(574) x, __int128 y, int z) {
  return x * y + x * z;
}
#endif

#if __BITINT_MAXWIDTH__ >= 274
__attribute__((noipa)) unsigned _BitInt(574)
    bar_574(unsigned _BitInt(574) x, _BitInt(231) y, unsigned _BitInt(231) z,
            unsigned _BitInt(574) a) {
  _BitInt(287) w = y;
  _BitInt(231) v = (_BitInt(231))z;
  _BitInt(287) u = v;
  return x * w + a * u;
}

__attribute__((noipa)) unsigned _BitInt(271)
    baz_574(unsigned _BitInt(271) x, _BitInt(574) y) {
  if (y >= 139845735984wb || y <= -139845735984wb)
    __builtin_unreachable();
  return x * (unsigned _BitInt(271))y;
}
#endif


