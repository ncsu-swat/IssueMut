
struct {  int i[];  char f;  char b[2];} s1;

int main() {
  struct {  int i[];  char f;  char b[2];} s2;
  s2.b[0] = 100;
  __builtin_memcpy(&s2, &s1, ((unsigned int)&((struct {  int i[];  char f;  char b[2];} *)0)->b));
  if (s2.b[0] != 100)
    abort();
  exit(0);
}
