/* PR c/102989 */
/* { dg-do compile { target bitint } } */
/* { dg-options "-O2 -std=c2x -pedantic-errors" } */

#if __BITINT_MAXWIDTH__ >= 315
_Bool foo(_BitInt(66666666666666666666wb) a, _BitInt(315) b, unsigned *c) {
  if (a < -8 || a > 7)
    __builtin_unreachable();
  if (b < 0 || b > 63)
    __builtin_unreachable();
  return __builtin_add_overflow(a, b, c);
}
#else
short int i;
#endif
