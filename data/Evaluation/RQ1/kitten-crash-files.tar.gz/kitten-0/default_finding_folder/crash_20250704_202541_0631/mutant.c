void
foo
(
void
)
__asm
(
"\0abcdefghijklmno"
"%d:%d:\"%s\""
"RDS Music"
"Video Decoder PTS"
"pqr"
"wv1"
"%o"
"%0+ DG\n"
"HEVC Hierarchical Layer 5 QP"
)
;
void
bar
(
void
)
{
foo
(
)
;
}
