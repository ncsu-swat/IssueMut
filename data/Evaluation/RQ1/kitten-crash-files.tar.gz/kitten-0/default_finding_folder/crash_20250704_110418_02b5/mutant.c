#include <stdio.h>
__attribute__
(
(
target_clones
(
"avx"
,
"arch=slm"
,
"arch=core-avx2"
,
"default"
)
)
)
int
hp1
(
void
)
{
printf
(
"hello, world!\n"
)
;
}
