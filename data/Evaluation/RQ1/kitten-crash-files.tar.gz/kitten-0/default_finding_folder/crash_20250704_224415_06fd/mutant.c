void
foo
(
void
)
asm
(
"_bar"
)
;
void
foo
(
void
)
{
}
extern
int
foobar
asm
(
"%X"
"ev"
"a\0cde"
"Video Encoding"
"standalone"
"string: %s\n"
"ABCDEFghijklmnopq\0"
"detected overflow"
"mystring"
)
;
int
foobar
=
3
;
