void
foo
(
void
)
asm
(
"\x8f"
"xyxyz"
"H264 Map Type for FMO"
"thunk-inline"
"fistp{l (%1)| DWORD PTR [%1]}\n\t"
"aaaaaaa"
"\0\0\0\0"
)
;
void
bar
(
void
)
{
foo
(
)
;
}
