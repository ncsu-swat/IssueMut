void foo ( void * ptr , long n ) {
__asm__ __volatile__ ( "" : : "m" ( ( {
struct {
char x [ n ] ;
} * p = ptr
;
} ) ) ) ;
}
void bar ( void * ptr , long n ) {
__asm__ __volatile__ ( "" : : "m" ( * ( {
struct {
char x [ n ] ;
} * p = ptr ;
p ;
} ) ) ) ;
}
