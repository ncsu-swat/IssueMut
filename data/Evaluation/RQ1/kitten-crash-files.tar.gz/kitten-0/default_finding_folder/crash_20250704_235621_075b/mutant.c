void
foo
(
)
__asm__
(
"open with O_CREAT needs 3 arguments, only 2 were given"
"green: %f\nblue: %p\nblue again: %p\n"
"1234111127"
"j\0\0\0\0\0\0\0\0"
"big-endian"
"\x2b"
"foo: %d\n"
)
;
void
foo
(
)
{
}
int
main
(
)
{
foo
(
)
;
return
0
;
}
