extern
void
foo
(
void
)
asm
(
"call bar"
"movl %3, %0; movl %4, %1; movl %5, %2"
"RDS Artificial Head"
"456456\0"
"ac"
".frog1"
)
;
int
bar
(
void
)
{
foo
(
)
;
return
0
;
}
