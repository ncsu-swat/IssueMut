int
X
__asm__
(
"clean"
"=m"
"%g\n"
"RSTUVWXYVWSlmnrsq\0"
"Some text"
"return val"
"\xb4"
"gtsf2 0>1"
)
=
123
;
