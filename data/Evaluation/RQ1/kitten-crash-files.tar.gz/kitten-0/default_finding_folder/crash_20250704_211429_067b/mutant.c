int
(
identifier_39349
)
__asm__
(
"MODE_VECTOR_FLOAT"
"o"
"H264 Picture Parameter Set"
"HEVC Slice Parameters"
"  xor %eax, %eax\n"
"xenon"
"ABCDx\0G\0ijklmnop"
"dyn\n"
)
__attribute__
(
(
)
)
__attribute__
(
(
)
)
;
int
x
;
