void foo ( void ) {
__asm__ (
""
:
: "m" ( ( {
static
a ;
} ) ) ) ;
}
