void bar(void);
void __attribute__((noinline)) * foo1(void) {
  bar();
  return __builtin_assoc_barrier((void *)bar);
}
