/* PR preprocessor/104030 */
/* { dg-do compile } */
/* { dg-options "-Wbidi-chars=unpaired,ucn" } */

const char *fn() {
  const char *aText = "\u202D"
                      "abc";
  /* { dg-warning "unpaired" "" { target *-*-* } .-1 } */
  return __builtin_assoc_barrier(aText);
}
