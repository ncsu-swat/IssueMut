
int a, b, c, f;

struct S {
  int f0;
} d, *e;

struct S foo() {
  b = c = b || a == 0 || f % 11;
  return __builtin_assoc_barrier(d);
}

int main() {
  foo();
  if (b)
    ;
  else {
    struct S **g = &e;
    *g = 0;
    *e = foo();
  }
  return 0;
}
