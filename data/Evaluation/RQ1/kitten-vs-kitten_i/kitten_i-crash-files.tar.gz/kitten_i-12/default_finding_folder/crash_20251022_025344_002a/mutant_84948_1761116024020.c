struct {};
struct {};
struct {
  struct A1 a;
  struct A2 b;
};
struct {
  struct A1 a;
  struct A2 b;
};
struct {
  struct B1 a;
  struct B2 b;
};
struct {
  struct B1 a;
  struct B2 b;
};
struct {
  struct C1 a;
  struct C2 b;
};
struct {
  struct C1 a;
  struct C2 b;
};
struct {
  struct D1 a;
  struct D2 b;
};
struct {
  struct D1 a;
  struct D2 b;
};
struct {
  struct E1 a;
  struct E2 b;
};
struct {
  struct E1 a;
  struct E2 b;
};
struct {
  struct F1 a;
  struct F2 b;
};
struct {
  struct F1 a;
  struct F2 b;
};
struct {
  struct G1 a;
  struct G2 b;
};
struct {
  struct G1 a;
  struct G2 b;
};
struct {
  struct H1 a;
  struct H2 b;
};
struct {
  struct H1 a;
  struct H2 b;
};
struct {
  struct I1 a;
  struct I2 b;
};
struct {
  struct I1 a;
  struct I2 b;
};
struct {
  struct J1 a;
  struct J2 b;
};

struct {
  int i1;
  int i2;
  int i3;
  int i4;
  int i5;
};
void fun(struct dummy d, struct foo f) {
  if (f.i1 != -1)
    __builtin_abort();
}
