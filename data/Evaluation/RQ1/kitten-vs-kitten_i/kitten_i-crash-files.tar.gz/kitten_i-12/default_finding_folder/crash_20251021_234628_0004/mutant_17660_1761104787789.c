/* { dg-do compile { target fpic } } */
/* { dg-options "-O2 -fPIC" } */
double c;
double d;
double *f(int a) {
  if (a)
    return __builtin_assoc_barrier(&c);
  return &d;
}
