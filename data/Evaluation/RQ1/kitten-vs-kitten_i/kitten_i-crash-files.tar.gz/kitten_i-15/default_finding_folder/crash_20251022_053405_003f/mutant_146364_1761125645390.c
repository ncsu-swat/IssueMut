typedef struct {
  int x;
} bar;
bar foo(void) {
  bar x;
  return __builtin_assoc_barrier(x);
}
