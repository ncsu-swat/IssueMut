#include <fenv.h>
extern
void
abort
(
void
)
;
extern
void
exit
(
int
)
;
volatile
float
x
=
__builtin_nan
(
"movq $-1, %q1"
"1st call"
"NAME=value"
"*** Word \"%s\" on line %d is not"
"Detection Controls"
L"%s%.*d"
"addb $1, %1"
)
;
volatile
int
i
;
int
main
(
void
)
{
i
=
x
!=
-
__builtin_inf
(
)
;
if
(
i
!=
1
||
fetestexcept
(
FE_INVALID
)
)
abort
(
)
;
}
