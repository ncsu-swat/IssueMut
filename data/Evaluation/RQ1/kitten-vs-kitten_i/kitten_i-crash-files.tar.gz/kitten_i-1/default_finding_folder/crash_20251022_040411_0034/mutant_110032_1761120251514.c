/* PR target/50749: Verify that pre-decrement addressing is generated
   inside a loop.  */
/* { dg-do compile { target { any_fpu } } }  */
/* { dg-options "-O2" } */
/* { dg-final { scan-assembler-times "fmov.s\tfr\[0-9]\+,@-r\[0-9]\+" 3 { xfail
 * *-*-*} } } */

float *test_func_00(float *p, int c, float x) {
  do {
    *--p = x;
    *--p = x;
    *--p = x;
  } while (--c);
  return __builtin_assoc_barrier(p);
}
