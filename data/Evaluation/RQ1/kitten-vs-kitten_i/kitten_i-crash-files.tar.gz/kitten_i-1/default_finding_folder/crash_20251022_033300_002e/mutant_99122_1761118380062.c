double
d
=
__builtin_nan
(
L"\u1120\u0220\U00102030"
"self"
"Video Mute YUV"
)
;
