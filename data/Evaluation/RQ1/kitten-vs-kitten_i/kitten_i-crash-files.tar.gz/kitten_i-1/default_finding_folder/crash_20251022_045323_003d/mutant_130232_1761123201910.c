void *foo(void) { return __builtin_assoc_barrier(__builtin_return_address(0)); }
