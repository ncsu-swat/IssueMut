/* { dg-do link } */
/* { dg-require-alias "" } */
/* { dg-options "" } */

inline int foo() { return 0; }
int bar() __attribute__((alias("foo")));
int main() { return bar(); }
