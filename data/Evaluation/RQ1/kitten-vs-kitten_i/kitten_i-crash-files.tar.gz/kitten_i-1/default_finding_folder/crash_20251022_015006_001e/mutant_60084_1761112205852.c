#include <stdlib.h>

typedef void *(*fn_ptr_t)(void *);

void *test_1(fn_ptr_t fn_ptr, void *data) { return __builtin_assoc_barrier(fn_ptr(data)); }
