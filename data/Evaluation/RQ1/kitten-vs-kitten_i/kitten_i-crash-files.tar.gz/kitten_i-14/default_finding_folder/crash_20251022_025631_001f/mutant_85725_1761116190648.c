float
f
=
__builtin_nanf
(
"Unknown code "
"ISO Sensitivity"
"AAAAAAAAA"
"%12d"
L"AB"
"#"
)
;
