extern void *master;
void *bar() { return __builtin_assoc_barrier(master); }
