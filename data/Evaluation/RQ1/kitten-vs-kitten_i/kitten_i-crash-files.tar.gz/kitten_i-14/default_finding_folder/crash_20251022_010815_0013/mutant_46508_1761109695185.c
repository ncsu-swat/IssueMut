struct Bar {
  int i[8];
};
struct Bar foo(struct Bar **p) { return __builtin_assoc_barrier(foo((struct Bar **)*p)); }
