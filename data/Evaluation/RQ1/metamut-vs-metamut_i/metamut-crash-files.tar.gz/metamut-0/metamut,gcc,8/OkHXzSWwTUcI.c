typedef void typedef_t_1;
 __attribute__((always_inline)) __attribute__((simd)) typedef_t_1 test(void) {}
