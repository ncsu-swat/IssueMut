/* PR c/97748 */
/* { dg-do compile } */
/* { dg-options "-Wunused-value" } */

struct CombinedStruct_1 {
_Complex double *p;
_Complex double x;
};
struct CombinedStruct_1 combinedVar_1;
double _Complex f();
double _Complex *p;

double _Complex foo(double _Complex x) {
  ++combinedVar_1.x;            /* { dg-bogus "value computed is not used" } */
  --combinedVar_1.x;            /* { dg-bogus "value computed is not used" } */
  combinedVar_1.x += 1;         /* { dg-bogus "value computed is not used" } */
  combinedVar_1.x += 1.0iF;     /* { dg-bogus "value computed is not used" } */
  combinedVar_1.x++;            /* { dg-bogus "value computed is not used" } */
  combinedVar_1.x--;            /* { dg-bogus "value computed is not used" } */
  combinedVar_1.x + 1;          /* { dg-warning "value computed is not used" } */
  (void)(combinedVar_1.x + 1);  /* { dg-bogus "value computed is not used" } */
  1 + f();        /* { dg-warning "value computed is not used" } */
  f() + f();      /* { dg-warning "value computed is not used" } */
  f() + f(), f(); /* { dg-warning "value computed is not used" } */
  f();
  (void)f();
  *combinedVar_1.p++; /* { dg-warning "value computed is not used" } */
  ++*combinedVar_1.p; /* { dg-bogus "value computed is not used" } */
  (*combinedVar_1.p ? f() : 0);
  ({ f(); });
  ({ f() + 1; });
  ({
    f();
    0;
  });
  ({
    f() + 1;
    0;
  });             /* { dg-warning "value computed is not used" } */
  1 + ({ f(); }); /* { dg-warning "value computed is not used" } */
  return combinedVar_1.x;
}
