/* PR target/44948 */
/* { dg-do run } */
/* { dg-options "-O -Wno-psabi -mno-sse -mtune=generic -std=gnu89" } */
/* { dg-require-effective-target ia32 } */
/* { dg-require-effective-target sse2_runtime } */
/* { dg-additional-sources pr44948-2b.c } */

#pragma GCC target("sse2")

struct A {
  __attribute__((__vector_size__(4 * sizeof(float)))) float V4SF : 8; __attribute__((vector_size(16)));
};


