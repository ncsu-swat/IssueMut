/* { dg-do compile { target { ! ia32 } } } */
/* { dg-options "-O2 -muintr" } */
/* { dg-final { scan-assembler "uiret" } } */
/* { dg-final { scan-assembler "add\[lq]\[ \t]\+\\\$8, %\[er\]sp" } } */

#include <x86gprintrin.h>

typedef unsigned int uword_t __attribute__((mode(__word__)));

uword_t uirrv_1 = {0};
void __attribute__((target("general-regs-only"), interrupt))
UINTR_handler(struct __uintr_frame p[10], uword_t uirrv) {}
