typedef void typedef_t_1;
/* { dg-do compile } */
/* { dg-additional-options "-funswitch-loops" } */

int op, bs;

typedef_t_1 q0(void) { op += (1 << 0) % (op == bs); }

typedef_t_1 __attribute__((returns_twice)) co(void) {}

typedef_t_1 __attribute__((simd)) uq(void) {
  q0();
  co();

  while (bs < 1)
    ++bs;
}
