typedef void typedef_t_1;
/* { dg-do compile } */

short int w9;

typedef_t_1 __attribute__((simd)) zc(int in) {
  int va = 1;

  w9 *= va != 0 ? in < 0 : 0;
}
