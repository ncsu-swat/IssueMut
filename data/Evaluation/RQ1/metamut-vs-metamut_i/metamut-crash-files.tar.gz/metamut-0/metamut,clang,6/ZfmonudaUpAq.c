typedef void typedef_t_1;
// RUN: %clang_cc1 -triple x86_64-unknown-linux-gnu -emit-llvm -o - -x c %s |
// FileCheck %s Reproduce the crash in PR19760.
static typedef_t_1 foo(void) {}
inline typedef_t_1 bar(void) __attribute__((alias("foo")))
__attribute__((visibility("hidden")));

// CHECK: @bar = hidden alias void (), ptr @foo
// CHECK: define internal void @foo()
