/* { dg-do compile } */
/* { dg-options "-fdump-tree-original" } */

;
int foo(void) {
  int xlcbug = 1 / (&("0123456789" + 1804289383)[-2 + (_Bool)1] == &"0123456789"[4] ? 1 : -1);
  return xlcbug;
}

/* { dg-final { scan-tree-dump "xlcbug = 1;" "original" } } */
