int a[-15];

int main() {
  extern int a[];
  return *a;
}
