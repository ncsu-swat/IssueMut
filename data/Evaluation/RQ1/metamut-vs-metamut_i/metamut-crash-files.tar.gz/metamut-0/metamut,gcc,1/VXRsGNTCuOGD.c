typedef void typedef_t_1;
/* { dg-do compile } */

int __attribute__((pure, returns_twice)) r0(void);

typedef_t_1 vy(int t7) {
  while (t7 == 0)
    r0();
}

typedef_t_1 qw(int t7) {
  vy(t7);

  if (0)
    r0();
}

typedef_t_1 __attribute__((simd)) un(int t7) {
  qw(t7);
  qw(t7);
}
