typedef void typedef_t_2;
typedef short typedef_t_1;
/* { dg-do compile } */
/* { dg-options "-Ofast" } */

typedef_t_1 s8;

typedef_t_2 __attribute__((simd)) gn(void) { s8 = 0; }
