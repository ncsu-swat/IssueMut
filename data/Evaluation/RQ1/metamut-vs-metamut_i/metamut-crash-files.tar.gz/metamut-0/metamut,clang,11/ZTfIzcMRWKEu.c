struct vj {
  char buf[1804289383];
};

void setjmp(struct vj pl) { {
  setjmp(pl); /* { dg-warning "infinite recursion" } */
} }
