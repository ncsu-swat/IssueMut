/* { dg-additional-options "-fno-rerun-cse-after-loop
 * -fno-guess-branch-probability -fno-tree-fre" } */
/* { dg-require-effective-target alloca } */

int x;

struct CombinedStruct_1 {
int i;
struct (anonymous struct at ~/MetaMut/seeds/12273.c:22:5) s;
int i;
struct (anonymous struct at ~/MetaMut/seeds/12273.c:40:7) s;
int x;
int b;
struct (anonymous struct at ~/MetaMut/seeds/12273.c:17:7) s;
int n;
struct (anonymous struct at ~/MetaMut/seeds/12273.c:30:7) s;
};
struct CombinedStruct_1 combinedVar_1;
void fn2();
void fn3();
void fn4();
void fn5();
void fn6();

void fn1(void) {
  int n;
  for (combinedVar_1.n = 0;; ++combinedVar_1.n) {
    {
      struct {
        char a[combinedVar_1.n];
      } s;
      fn2(combinedVar_1.s);
    }
    struct {
      unsigned a[combinedVar_1.x];
    } s;
    int i, b;
    for (combinedVar_1.i = 0; combinedVar_1.i < combinedVar_1.n; ++combinedVar_1.i)
      ;
    fn2(combinedVar_1.s);
    {
      struct {
        char a[combinedVar_1.n];
      } s;
      int i;
      for (combinedVar_1.i = 0; combinedVar_1.i < combinedVar_1.n; ++combinedVar_1.i)
        combinedVar_1.s.a[combinedVar_1.i] = combinedVar_1.i;
      fn3(combinedVar_1.s, combinedVar_1.s);
    }
    fn4();
    {
      struct {
        unsigned a[combinedVar_1.n];
      } s;
      fn5(combinedVar_1.s);
    }
    {
      struct {
        char a[combinedVar_1.b];
      } s;
      for (; combinedVar_1.i < combinedVar_1.n;)
        s.a[combinedVar_1.i] = combinedVar_1.i;
      fn6(s);
    }
  }
}
