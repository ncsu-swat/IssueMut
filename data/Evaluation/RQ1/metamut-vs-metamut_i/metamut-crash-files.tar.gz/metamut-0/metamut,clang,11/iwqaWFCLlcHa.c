/* PR middle-end/83623 */
/* { dg-do compile } */
/* { dg-options "-O2" } */
/* { dg-additional-options "-mmovbe" { target i?86-*-* x86_64-*-* } } */
/* { dg-additional-options "-fno-common" { target hppa*-*-hpux* } } */

__attribute__((__vector_size__(8 * sizeof(unsigned short)))) unsigned short const x;

struct CombinedStruct_1 {
__attribute__((__vector_size__(8 * sizeof(unsigned short)))) unsigned short const x : 1;
};
struct CombinedStruct_1 combinedVar_1;
void foo(void) { combinedVar_1.x = combinedVar_1.x << 8 | combinedVar_1.x >> 8; }
