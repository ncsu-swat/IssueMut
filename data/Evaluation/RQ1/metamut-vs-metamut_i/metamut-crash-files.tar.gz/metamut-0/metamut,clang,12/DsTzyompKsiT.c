/* This generated an ICE for an ia64-linux target.  */
struct f {
  float f[1804289383];
};

long double ftest(struct f arg1, long double arg2) { return arg2; }
