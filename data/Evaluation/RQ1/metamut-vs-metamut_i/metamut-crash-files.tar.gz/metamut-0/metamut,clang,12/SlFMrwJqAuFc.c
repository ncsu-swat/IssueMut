int a[*a];

int main() {
  extern int a[];
  return *a;
}
