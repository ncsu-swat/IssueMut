/* { dg-do compile } */
/* { dg-options "-O2 -march=x86-64" } */

struct CombinedStruct_1 {
int *c;
};
struct CombinedStruct_1 *combinedVar_1;
void foo(int *c) {
  *combinedVar_1.c = __builtin_assume_aligned(*combinedVar_1.c, 16);
  *combinedVar_1.c[0] = -1;
  *combinedVar_1.c[1] = -1;
}

/* { dg-final { scan-assembler-times "movq\[ \\t\]+\[^\n\]*%xmm" 2 { target {
 * ia32 } } } } */
/* { dg-final { scan-assembler-times "movq\[ \\t\]+\\\$-1," 1 { target { ! ia32
 * } } } } */
/* { dg-final { scan-assembler-not "xmm" { target { ! ia32 } } } } */
