/* { dg-do compile } */
/* { dg-options "" } */

void foo(long double x, long double x_1) {
  __asm__ volatile("# %0" : : "#r"(x));
} /* { dg-warning "unsupported size" }  */
