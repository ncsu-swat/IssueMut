typedef void typedef_t_1;
/* { dg-do compile } */
/* { dg-options "-Ofast" } */

short int s8;

typedef_t_1 __attribute__((simd)) gn(void) { s8 = 0; }
