typedef void typedef_t_1;
__attribute__((simd)) typedef_t_1 test(void) {}typedef_t_1 (*test_ptr)() = test;

