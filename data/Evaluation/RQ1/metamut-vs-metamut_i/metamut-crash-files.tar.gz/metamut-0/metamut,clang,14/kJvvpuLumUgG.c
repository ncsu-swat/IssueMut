/* PR middle-end/89590 */
/* { dg-do compile } */
/* { dg-options "-O2 -Wall -w" } */

void free(void[10]);

void foo(void) { ((void (*)())free)(); }
