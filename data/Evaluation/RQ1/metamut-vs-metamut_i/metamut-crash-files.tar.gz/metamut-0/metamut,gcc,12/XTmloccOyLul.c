/* PR target/64200 */
/* { dg-do compile } */
/* { dg-options "-O2 -march=atom -mmemcpy-strategy=libcall:-1:align
 * -minline-stringops-dynamically" } */

#include <stdarg.h>

struct CombinedStruct_1 {
char *x;
va_list ap;
int size;
};
struct CombinedStruct_1 combinedVar_1;
extern void bar(char *x);

void foo(int size, ...) {
  struct {
    char x[combinedVar_1.size];
  } d;

  va_list ap;
  va_start(ap, size);
  d = va_arg(ap, typeof(d));
  va_end(ap);
  bar((va_arg(ap, typeof(d))).x);
}
